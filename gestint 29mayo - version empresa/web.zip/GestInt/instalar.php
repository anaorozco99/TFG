<?php
// conexión directa como root — no usar db.php aquí
$conn = new mysqli('localhost', 'root', '', 'gestint');
$conn->set_charset('utf8mb4');

if ($conn->connect_error) {
    die('<p style="color:red;padding:2rem;">Error de conexión: ' . $conn->connect_error . '</p>');
}

$ok  = [];
$err = [];

$conn->query("SET FOREIGN_KEY_CHECKS = 0");

$tablas = [
    "usuarios" => "CREATE TABLE IF NOT EXISTS usuarios (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nombre     VARCHAR(80)  NOT NULL,
        apellidos  VARCHAR(100) NOT NULL DEFAULT '',
        usuario    VARCHAR(50)  NOT NULL UNIQUE,
        email      VARCHAR(120) NOT NULL,
        password   VARCHAR(255) NOT NULL,
        rol        ENUM('admin','rrhh','almacen','empleado') NOT NULL DEFAULT 'empleado',
        activo     TINYINT(1)   NOT NULL DEFAULT 1,
        created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",

    "empleados" => "CREATE TABLE IF NOT EXISTS empleados (
        id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        id_usuario   INT UNSIGNED NOT NULL,
        nombre       VARCHAR(80)  NOT NULL,
        apellidos    VARCHAR(100) NOT NULL,
        dni          CHAR(9)      NOT NULL UNIQUE,
        email        VARCHAR(120) NOT NULL,
        telefono     VARCHAR(20)  DEFAULT NULL,
        departamento VARCHAR(60)  NOT NULL,
        cargo        VARCHAR(80)  DEFAULT NULL,
        fecha_alta   DATE         NOT NULL,
        salario      DECIMAL(10,2) DEFAULT 0.00,
        activo       TINYINT(1)   NOT NULL DEFAULT 1,
        created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_empleados_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
    ) ENGINE=InnoDB",

    "inventario" => "CREATE TABLE IF NOT EXISTS inventario (
        id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nombre          VARCHAR(150) NOT NULL,
        categoria       VARCHAR(60)  NOT NULL DEFAULT 'Otros',
        descripcion     TEXT         DEFAULT NULL,
        cantidad        INT          NOT NULL DEFAULT 0,
        stock_minimo    INT          NOT NULL DEFAULT 5,
        unidad          VARCHAR(30)  NOT NULL DEFAULT 'unidad',
        proveedor       VARCHAR(100) DEFAULT NULL,
        precio_unitario DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        fecha_entrada   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",

    "pedidos" => "CREATE TABLE IF NOT EXISTS pedidos (
        id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id    INT UNSIGNED NOT NULL,
        estado        ENUM('pendiente','enviado','recibido') NOT NULL DEFAULT 'pendiente',
        fecha_pedido  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        fecha_llegada DATETIME GENERATED ALWAYS AS (DATE_ADD(fecha_pedido, INTERVAL 24 HOUR)) STORED,
        notas         TEXT DEFAULT NULL,
        CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ) ENGINE=InnoDB",

    "pedidos_lineas" => "CREATE TABLE IF NOT EXISTS pedidos_lineas (
        id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pedido_id     INT UNSIGNED NOT NULL,
        inventario_id INT UNSIGNED NOT NULL,
        nombre        VARCHAR(150) NOT NULL,
        cantidad      INT          NOT NULL DEFAULT 1,
        CONSTRAINT fk_lineas_pedido     FOREIGN KEY (pedido_id)     REFERENCES pedidos(id)    ON DELETE CASCADE,
        CONSTRAINT fk_lineas_inventario FOREIGN KEY (inventario_id) REFERENCES inventario(id)
    ) ENGINE=InnoDB",

    "logs_acceso" => "CREATE TABLE IF NOT EXISTS logs_acceso (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        ip         VARCHAR(45)  NOT NULL,
        fecha      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_logs_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ) ENGINE=InnoDB",
];

foreach ($tablas as $nombre => $sql) {
    $conn->query($sql);
    if ($conn->error) $err[] = "Tabla $nombre: " . $conn->error;
    else $ok[] = "Tabla <b>$nombre</b> creada";
}

$conn->query("SET FOREIGN_KEY_CHECKS = 1");

// [nombre, apellidos, usuario, email, pass, rol, [dni, email, tel, depto, cargo, fecha, salario]]
$datos = [
    ['Michael', 'Scott',      'michael', 'michael.scott@dundermifflin.com',  'Michael1234', 'admin',
        ['12345678Z', 'michael.scott@dundermifflin.com',  '570100001', 'Dirección',    'Regional Manager',     '2005-03-24', 65000]],
    ['Dwight',  'Schrute',    'dwight',  'dwight.schrute@dundermifflin.com', 'Dwight1234',  'almacen',
        ['23456789D', 'dwight.schrute@dundermifflin.com', '570100002', 'Ventas',       'Assistant to the RM',  '2005-03-24', 42000]],
    ['Jim',     'Halpert',    'jim',     'jim.halpert@dundermifflin.com',    'Jim1234!!',   'empleado',
        ['34567890V', 'jim.halpert@dundermifflin.com',    '570100003', 'Ventas',       'Sales Representative', '2005-03-24', 40000]],
    ['Pam',     'Beesly',     'pam',     'pam.beesly@dundermifflin.com',     'Pam1234!!',   'rrhh',
        ['45678901G', 'pam.beesly@dundermifflin.com',     '570100004', 'Recepción',    'Receptionist',         '2005-03-24', 32000]],
    ['Toby',    'Flenderson', 'toby',    'toby.flenderson@dundermifflin.com','Toby1234!',   'rrhh',
        ['56789012B', 'toby.flenderson@dundermifflin.com','570100005', 'RRHH',         'HR Representative',    '2005-03-24', 38000]],
    ['Angela',  'Martin',     'angela',  'angela.martin@dundermifflin.com',  'Angela1234',  'empleado',
        ['67890123B', 'angela.martin@dundermifflin.com',  '570100006', 'Contabilidad', 'Head of Accounting',   '2005-03-24', 41000]],
    ['Oscar',   'Martinez',   'oscar',   'oscar.martinez@dundermifflin.com', 'Oscar1234!',  'empleado',
        ['78901234X', 'oscar.martinez@dundermifflin.com', '570100007', 'Contabilidad', 'Accountant',           '2005-03-24', 39000]],
    ['Kevin',   'Malone',     'kevin',   'kevin.malone@dundermifflin.com',   'Kevin1234!',  'empleado',
        ['89012345E', 'kevin.malone@dundermifflin.com',   '570100008', 'Contabilidad', 'Accountant',           '2005-03-24', 36000]],
    ['Stanley', 'Hudson',     'stanley', 'stanley.hudson@dundermifflin.com', 'Stanley1234', 'empleado',
        ['90123456A', 'stanley.hudson@dundermifflin.com', '570100009', 'Ventas',       'Sales Representative', '2005-03-24', 40000]],
    ['Phyllis', 'Vance',      'phyllis', 'phyllis.vance@dundermifflin.com',  'Phyllis1234', 'empleado',
        ['12345679S', 'phyllis.vance@dundermifflin.com',  '570100010', 'Ventas',       'Sales Representative', '2005-03-24', 39000]],
    ['Andy',    'Bernard',    'andy',    'andy.bernard@dundermifflin.com',   'Andy1234!!',  'empleado',
        ['11223344B', 'andy.bernard@dundermifflin.com',   '570100011', 'Ventas',       'Sales Representative', '2007-01-15', 39000]],
    ['Darryl',  'Philbin',    'darryl',  'darryl.philbin@dundermifflin.com', 'Darryl1234',  'almacen',
        ['22334455Y', 'darryl.philbin@dundermifflin.com', '570100012', 'Almacén',      'Warehouse Foreman',    '2005-03-24', 37000]],
    ['Roy',     'Anderson',   'roy',     'roy.anderson@dundermifflin.com',   'Roy12345!',   'almacen',
        ['33445566R', 'roy.anderson@dundermifflin.com',   '570100013', 'Almacén',      'Warehouse Worker',     '2005-03-24', 32000]],
];

foreach ($datos as [$nom, $ape, $usr, $email, $pass, $rol, $emp]) {
    $hash  = password_hash($pass, PASSWORD_DEFAULT);
    $stmtU = $conn->prepare("INSERT IGNORE INTO usuarios (nombre,apellidos,usuario,email,password,rol) VALUES (?,?,?,?,?,?)");
    $stmtU->bind_param('ssssss', $nom, $ape, $usr, $email, $hash, $rol);
    $stmtU->execute();
    if ($conn->error) { $err[] = "Usuario $usr: " . $conn->error; continue; }
    $ok[] = "Usuario <b>$usr</b> — $rol — pass: $pass";

    $uid = $conn->query("SELECT id FROM usuarios WHERE usuario = '$usr' LIMIT 1")->fetch_row()[0];
    [$dni, $emp_email, $tel, $dep, $cargo, $fecha, $sal] = $emp;

    $stmtE = $conn->prepare("INSERT IGNORE INTO empleados (id_usuario,nombre,apellidos,dni,email,telefono,departamento,cargo,fecha_alta,salario) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmtE->bind_param('issssssssd', $uid, $nom, $ape, $dni, $emp_email, $tel, $dep, $cargo, $fecha, $sal);
    $stmtE->execute();
    if ($conn->error) $err[] = "Empleado $nom: " . $conn->error;
    else $ok[] = "Empleado <b>$nom $ape</b> — DNI: $dni";
}

$inventario = [
    ['Papel A4 80g (500 hojas)',     'Papel',       500, 100, 'paquete', 'Navigator',   4.20],
    ['Papel A3 80g (500 hojas)',     'Papel',       120,  30, 'paquete', 'Navigator',   7.50],
    ['Papel carta 75g (500 hojas)',  'Papel',        80,  20, 'paquete', 'HP',          3.90],
    ['Papel reciclado A4 (500h)',    'Papel',       200,  50, 'paquete', 'Steinbeis',   3.60],
    ['Sobres blancos C4 (caja 250)', 'Sobres',       40,  10, 'caja',   'Liderpapel', 12.50],
    ['Sobres ventana DL (caja 500)', 'Sobres',       35,  10, 'caja',   'Liderpapel',  9.90],
    ['Carpetas A4 azul (caja 50)',   'Carpetas',     60,  15, 'caja',   'Leitz',      18.00],
    ['Archivadores A4 negro',        'Carpetas',     45,  10, 'unidad', 'Leitz',       3.80],
    ['Bolígrafos azul BIC (caja)',   'Escritura',    25,   5, 'caja',   'BIC',         8.50],
    ['Bolígrafos negro BIC (caja)',  'Escritura',    20,   5, 'caja',   'BIC',         8.50],
    ['Rotuladores permanentes (12)', 'Escritura',    18,   5, 'caja',   'Sharpie',    11.00],
    ['Tóner HP LaserJet negro',      'Consumibles',   6,   2, 'unidad', 'HP',         49.00],
    ['Tóner HP color (pack 4)',      'Consumibles',   4,   2, 'pack',   'HP',        139.00],
    ['Grapadora de mesa',            'Oficina',      12,   3, 'unidad', 'Rapid',      14.00],
    ['Grapas 26/6 (caja 5000)',      'Oficina',      30,  10, 'caja',   'Rapid',       3.20],
    ['Celo 19mm x 33m (pack 10)',    'Oficina',      40,  10, 'pack',   '3M',          9.80],
    ['Post-it 76x76 (pack 12)',      'Oficina',      50,  15, 'pack',   '3M',         12.50],
    ['Tijeras de oficina',           'Oficina',      10,   3, 'unidad', 'Maped',       4.50],
];

foreach ($inventario as [$nom, $cat, $cant, $min, $uni, $prov, $precio]) {
    $stmt = $conn->prepare("INSERT IGNORE INTO inventario (nombre,categoria,cantidad,stock_minimo,unidad,proveedor,precio_unitario) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('ssiissd', $nom, $cat, $cant, $min, $uni, $prov, $precio);
    $stmt->execute();
    if ($conn->error) $err[] = "Inventario $nom: " . $conn->error;
    else $ok[] = "Artículo <b>$nom</b> añadido";
}

// usuarios MySQL por rol
$grants = [
    'login_gestint'    => ['SELECT ON gestint.usuarios'],
    'admin_gestint'    => ['ALL PRIVILEGES ON gestint.*'],
    'rrhh_gestint'     => ['SELECT, INSERT, UPDATE, DELETE ON gestint.empleados', 'SELECT, INSERT, UPDATE, DELETE ON gestint.usuarios', 'SELECT ON gestint.logs_acceso'],
    'almacen_gestint'  => ['SELECT, INSERT, UPDATE, DELETE ON gestint.inventario', 'SELECT, INSERT, UPDATE, DELETE ON gestint.pedidos', 'SELECT, INSERT, UPDATE, DELETE ON gestint.pedidos_lineas', 'SELECT ON gestint.usuarios'],
    'empleado_gestint' => ['SELECT ON gestint.inventario', 'SELECT ON gestint.pedidos', 'SELECT ON gestint.pedidos_lineas', 'SELECT ON gestint.usuarios', 'UPDATE (password) ON gestint.usuarios'],
];

$passes_mysql = [
    'login_gestint'    => 'Login2024!',
    'admin_gestint'    => 'Admin2024!',
    'rrhh_gestint'     => 'RRHH2024!',
    'almacen_gestint'  => 'Almacen2024!',
    'empleado_gestint' => 'Empleado2024!',
];

foreach ($grants as $usr => $permisos) {
    $pass = $passes_mysql[$usr];
    $conn->query("CREATE USER IF NOT EXISTS '$usr'@'localhost' IDENTIFIED BY '$pass'");
    if ($conn->error) { $err[] = "Usuario MySQL $usr: " . $conn->error; continue; }
    foreach ($permisos as $grant) {
        $conn->query("GRANT $grant TO '$usr'@'localhost'");
    }
    $ok[] = "Usuario MySQL <b>$usr</b> creado";
}
$conn->query("FLUSH PRIVILEGES");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dunder Mifflin — Instalador</title>
    <style>
        body  { font-family:sans-serif; max-width:700px; margin:50px auto; padding:0 20px; }
        h1    { color:#28597A; margin-bottom:4px; }
        .sub  { color:#069DE0; font-weight:700; margin-bottom:24px; }
        .ok   { background:#f0fdf4; border-left:4px solid #16a34a; padding:8px 14px; margin:3px 0; border-radius:4px; font-size:13px; }
        .err  { background:#fef2f2; border-left:4px solid #dc2626; padding:8px 14px; margin:3px 0; border-radius:4px; font-size:13px; }
        .warn { background:#fffbeb; border-left:4px solid #d97706; padding:12px 14px; margin-top:20px; border-radius:4px; font-size:13px; }
        .btn  { display:inline-block; margin-top:24px; padding:12px 28px; background:#069DE0; color:#fff; border-radius:6px; text-decoration:none; font-weight:700; }
        table { width:100%; border-collapse:collapse; margin-top:16px; font-size:13px; }
        th    { background:#28597A; color:#fff; padding:8px 12px; text-align:left; }
        td    { padding:7px 12px; border-bottom:1px solid #e2e8f0; }
        tr:nth-child(even) td { background:#f8fafc; }
    </style>
</head>
<body>
<h1>DUNDER MIFFLIN INC.</h1>
<p class="sub">Scranton Branch — Instalador GestInt</p>

<?php foreach ($ok as $m): ?><div class="ok">✓ <?= $m ?></div><?php endforeach; ?>
<?php foreach ($err as $m): ?><div class="err">✗ <?= htmlspecialchars($m) ?></div><?php endforeach; ?>

<?php if (empty($err)): ?>
    <div class="warn">⚠ <strong>Borra este archivo</strong> una vez hayas entrado al sistema.</div>
    <h2 style="margin-top:28px;color:#28597A;">Credenciales de acceso</h2>
    <table>
        <tr><th>Usuario</th><th>Contraseña</th><th>Rol</th><th>Empleado</th></tr>
        <tr><td>michael</td><td>Michael1234</td><td>Administrador</td>  <td>Michael Scott</td></tr>
        <tr><td>dwight</td> <td>Dwight1234</td> <td>Resp. Almacén</td> <td>Dwight Schrute</td></tr>
        <tr><td>jim</td>    <td>Jim1234!!</td>   <td>Empleado</td>     <td>Jim Halpert</td></tr>
        <tr><td>pam</td>    <td>Pam1234!!</td>   <td>Resp. RRHH</td>  <td>Pam Beesly</td></tr>
        <tr><td>toby</td>   <td>Toby1234!</td>   <td>Resp. RRHH</td>  <td>Toby Flenderson</td></tr>
        <tr><td>angela</td> <td>Angela1234</td>  <td>Empleado</td>     <td>Angela Martin</td></tr>
        <tr><td>oscar</td>  <td>Oscar1234!</td>  <td>Empleado</td>     <td>Oscar Martinez</td></tr>
        <tr><td>kevin</td>  <td>Kevin1234!</td>  <td>Empleado</td>     <td>Kevin Malone</td></tr>
        <tr><td>stanley</td><td>Stanley1234</td> <td>Empleado</td>     <td>Stanley Hudson</td></tr>
        <tr><td>phyllis</td><td>Phyllis1234</td> <td>Empleado</td>     <td>Phyllis Vance</td></tr>
        <tr><td>andy</td>   <td>Andy1234!!</td>  <td>Empleado</td>     <td>Andy Bernard</td></tr>
        <tr><td>darryl</td> <td>Darryl1234</td>  <td>Resp. Almacén</td><td>Darryl Philbin</td></tr>
        <tr><td>roy</td>    <td>Roy12345!</td>   <td>Resp. Almacén</td><td>Roy Anderson</td></tr>
    </table>
    <a href="login.php" class="btn">Ir al login →</a>
<?php else: ?>
    <div class="err" style="margin-top:16px;">Hay errores. Revisa la conexión en la línea 3 de instalar.php.</div>
<?php endif; ?>
</body>
</html>
